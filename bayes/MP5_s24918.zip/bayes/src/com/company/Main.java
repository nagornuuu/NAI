package com.company;

import java.util.*;
import java.io.*;

public class Main {

    private final Map<String, Double> classProbabilities = new HashMap<>(); // prawdopodobienstwo klassy
    private final Map<String, Map<String, Double>> featureProbabilities = new HashMap<>(); // prawdopodobieństwa cech

    public void train() throws IOException {
        BufferedReader bufferedReader = new BufferedReader(new FileReader("training.txt"));
        String line;
        while ((line = bufferedReader.readLine()) != null) {
            String[] tokens = line.split(","); // Dzielimy linię na tokeny
            String clazz = tokens[0]; //przypisujemy 1 token do clazz, ten token reprezentuje klasę
            if (!classProbabilities.containsKey(clazz)) {         //Sprawdzamy, czy mapa classProbabilities nie zawiera klucza odpowiadającego obecnej klasie clazz.
                classProbabilities.put(clazz, 0.0);               //Jeśli nie zawiera, dodajemy do mapy klasę jako klucz, a jako wartość przypisujemy początkową wartość 0.0.
                featureProbabilities.put(clazz, new HashMap<>()); //Dodatkowo, tworzymy nową pustą mapę w mapie featureProbabilities dla danej klasy clazz.
            }
            classProbabilities.put(clazz, classProbabilities.get(clazz) + 1); // Zwiększamy o 1 wartość w mapie classProbabilities dla klasy clazz. Ta wartość reprezentuje liczbę wystąpień danej klasy w danych treningowych.
            for (int i = 1; i < tokens.length; i++) { //iteruje po wszystkich tokenach (cechach) oprócz pierwszego (klasy) w tablicy tokens.
                String feature = tokens[i];
                if (!featureProbabilities.get(clazz).containsKey(feature)) { //Sprawdzamy, czy mapa featureProbabilities dla danej klasy clazz zawiera klucz odpowiadający aktualnej cechy feature.
                    featureProbabilities.get(clazz).put(feature, 0.0); //Jeśli nie zawiera, dodajemy do mapy dla danej klasy nowy klucz reprezentujący cechę, a jako wartość przypisujemy początkową wartość 0.0.
                }
                featureProbabilities.get(clazz).put(feature, featureProbabilities.get(clazz).get(feature) + 1); //Następnie zwiększamy o 1 wartość w mapie featureProbabilities dla danej klasy clazz i dla danej cechy feature. Ta wartość reprezentuje liczbę wystąpień danej cechy w danej klasie.
            }
        }
        bufferedReader.close();
        for (String clazz : classProbabilities.keySet()) { // Iteruje przez klassy w mapie classProbabilities. Każdy klucz reprezentuje klasę.
            double count = classProbabilities.get(clazz); //Pobiera wartość (liczbę wystąpień) dla danej klasy clazz z mapy classProbabilities i przypisuje ją do zmiennej count.
            if (count == 0) { // Sprawdzamy, czy licznik wynosi 0
                classProbabilities.put(clazz, laplace(count, getTotalCount(), classProbabilities.size())); // Stosujemy wygładzanie Laplace'a
            } else {
                classProbabilities.put(clazz, count / (getTotalCount() + classProbabilities.size())); // Bez wygładzania Laplace'a
            }
            Map<String, Double> probabilities = featureProbabilities.get(clazz); //Pobiera mapę prawdopodobieństw cech dla danej klasy clazz z mapy featureProbabilities i przypisuje ją do zmiennej probabilities.
            for (String feature : probabilities.keySet()) { // Iteruje przez zbiór cech w mapie probabilities. Każdy klucz reprezentuje cechę.
                double value = probabilities.get(feature); //Pobiera wartość (liczbę wystąpień) dla danej cechy feature z mapy probabilities i przypisuje ją do zmiennej value.
                if (value == 0) { // Sprawdzamy, czy licznik wynosi 0
                    probabilities.put(feature, laplace(value, count, probabilities.size())); // Stosujemy wygładzanie Laplace'a
                } else {
                    probabilities.put(feature, value / (count + probabilities.size())); // Bez wygładzania Laplace'a
                }
            }
        }
    }

    public double laplace(double numerator, double denominator, int vocabularySize) {
        return (numerator + 1) / (denominator + vocabularySize);
    }

    public void classify() throws IOException {
        BufferedReader bufferedReader = new BufferedReader(new FileReader("test.txt"));
        String line;
        while ((line = bufferedReader.readLine()) != null) {
            String[] tokens = line.split(",");
            double maxProbability = Double.NEGATIVE_INFINITY; // negative_infinity =  ujemną nieskończoność.
            String bestClass = null;
            for (String clazz : classProbabilities.keySet()) {
                double probability = Math.log(classProbabilities.get(clazz)); //Oblicza logarytm naturalny prawdopodobieństwa dla danej klasy clazz na podstawie wartości z mapy classProbabilities i przypisuje wynik do zmiennej probability.
                for (int i = 1; i < tokens.length; i++) { //która iteruje przez wszystkie tokeny w tablicy tokens, zaczynając od drugiego tokena (pomijając pierwszy, który reprezentuje klasę).
                    String feature = tokens[i]; //Przypisuje kolejny token do zmiennej feature, reprezentującej cechę.
                    if (featureProbabilities.get(clazz).containsKey(feature)) { //Sprawdza, czy mapa prawdopodobieństw cech dla danej klasy clazz zawiera klucz odpowiadający aktualnej cechy feature.
                        probability += Math.log(featureProbabilities.get(clazz).get(feature)); //eśli mapa zawiera klucz, oblicza logarytm naturalny prawdopodobieństwa cechy dla danej klasy clazz i aktualnej cechy feature na podstawie mapy featureProbabilities, a następnie dodaje ten wynik do zmiennej probability.
                    } else {
                        double smoothedProbability = laplace(0.0, 0.0, featureProbabilities.get(clazz).size()); // w celu wygładzenia Laplace'a i obliczenia wygładzonego prawdopodobieństwa dla brakującej cechy.
                        probability += Math.log(smoothedProbability); //Dodaje logarytm wygładzonego prawdopodobieństwa do zmiennej probability.
                    }
                }
                if (probability > maxProbability) {
                    maxProbability = probability;
                    bestClass = clazz;
                }
            }
            System.out.println("Classified as: " + bestClass);
        }
        bufferedReader.close();
    }

    // zwraca sumę wszystkich wartości z mapy classProbabilities
    private double getTotalCount() {
        double count = 0.0;
        for (double value : classProbabilities.values()) {
            count += value;
        }
        return count;
    }

    public static void main(String[] args) throws IOException {
        Main classifier = new Main();
        classifier.train();
        classifier.classify();
    }
}
